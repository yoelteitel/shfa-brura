
function startLearning() {
    alert("שלב א: כתוב את המילה הראשונה 3 פעמים...");
}
